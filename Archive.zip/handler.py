import json
import pymysql

#configuration values
endpoint = 'butterfly-db.cluster-ciewcmyvhuqs.us-west-1.rds.amazonaws.com'
username = 'admin'
password = "kjJiIcZilGsxdYDqWvrw"
db_name = "butterflies"

#connection
db = pymysql.connect(host=endpoint, user=username, passwd=password, db=db_name)

def lambda_handler(event, context):
    cursor=db.cursor()
    cursor.execute('SELECT * FROM users;')
    rows = cursor.fetchall()
    data = ""
    for row in rows:
        print("{0} {1} {2} {3} {4}".format(row[0], row[1], row[2], row[3], row[4]))
